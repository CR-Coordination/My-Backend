const { RateLimiterMemory } = require('rate-limiter-flexible');
const limiter = new RateLimiterMemory({ points: 100, duration: 60 });

module.exports = (req, res, next) => {
  limiter.consume(req.ip)
    .then(() => next())
    .catch(() => res.status(429).json({ error: 'Too many requests' }));
};
