require('dotenv').config();
const app = require('./app');
const mongoose = require('mongoose');
const path = require('path');

const MONGO = process.env.MONGO_URI || 'mongodb://mongo:27017/photoapp';
const PORT = process.env.PORT || 4000;

async function start(){
  await mongoose.connect(MONGO, { /* use defaults */ });
  console.log('Mongo connected');
  // Ensure local upload dir exists when using local storage
  if(process.env.USE_S3 !== 'true'){
    const up = path.resolve(process.env.LOCAL_UPLOAD_DIR || './uploads');
    require('fs').mkdirSync(up, { recursive: true });
  }
  app.listen(PORT, () => console.log('Server running on port', PORT));
}
start().catch(err=>{ console.error(err); process.exit(1); });
