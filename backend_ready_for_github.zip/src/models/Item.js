const mongoose = require('mongoose');

const ImageSchema = new mongoose.Schema({
  key: String,
  url: String,
  filename: String,
  size: Number,
  contentType: String
});

const FeedbackSchema = new mongoose.Schema({
  authorName: { type: String, default: 'Anonymous' },
  message: { type: String, required: true },
  rating: { type: Number, default: 0 },
  reply: { type: String },
  createdAt: { type: Date, default: Date.now }
});

const ItemSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  images: [ImageSchema],
  feedbacks: [FeedbackSchema],
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Item', ItemSchema);
