const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

router.post('/register', [
  body('email').isEmail(),
  body('password').isLength({ min: 8 })
], async (req,res) => {
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { email, password } = req.body;
  const salt = await bcrypt.genSalt(12);
  const hash = await bcrypt.hash(password, salt);
  try{
    const user = new User({ email, passwordHash: hash });
    await user.save();
    res.json({ ok: true });
  }catch(e){
    res.status(400).json({ error: 'User exists or invalid' });
  }
});

router.post('/login', [ body('email').isEmail(), body('password').exists() ], async (req,res) => {
  const user = await User.findOne({ email: req.body.email });
  if(!user) return res.status(401).json({ error: 'Invalid' });
  const ok = await user.verifyPassword(req.body.password);
  if(!ok) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user._id, email: user.email, role: user.role } });
});

module.exports = router;
