const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const { body, validationResult } = require('express-validator');

// Create item (owner must be authenticated)
router.post('/', auth, [ body('title').isString().trim().isLength({ min: 1 }) ], async (req,res) => {
  const errors = validationResult(req); if(!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { title, description, images } = req.body;
  const item = new Item({ title, description, images, owner: req.user.id });
  await item.save();
  res.json(item);
});

// List items (public)
router.get('/', async (req,res) => {
  const items = await Item.find().sort({ createdAt: -1 }).limit(100);
  res.json(items);
});

// Get item
router.get('/:id', async (req,res) => {
  const item = await Item.findById(req.params.id);
  if(!item) return res.status(404).json({ error: 'Not found' });
  res.json(item);
});

// Add feedback (public)
router.post('/:id/feedback', [ body('authorName').optional().isString().trim().escape(), body('message').isString().trim().isLength({ min: 1 }) ], async (req,res) => {
  const item = await Item.findById(req.params.id);
  if(!item) return res.status(404).json({ error: 'Not found' });
  const fb = { authorName: req.body.authorName || 'Anonymous', message: req.body.message, rating: Number(req.body.rating) || 0 };
  item.feedbacks.push(fb);
  await item.save();
  res.json({ ok: true, feedback: fb });
});

// Admin reply to feedback
router.post('/:itemId/feedback/:feedbackId/reply', auth, admin, async (req,res) => {
  try{
    const { reply } = req.body;
    const item = await Item.findById(req.params.itemId);
    if(!item) return res.status(404).json({ message: 'Item not found' });
    const feedback = item.feedbacks.id(req.params.feedbackId);
    if(!feedback) return res.status(404).json({ message: 'Feedback not found' });
    feedback.reply = reply;
    await item.save();
    res.json({ message: 'Reply added', feedback });
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete item (admin)
router.delete('/:id', auth, admin, async (req,res) => {
  await Item.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
