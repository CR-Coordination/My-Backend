const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const auth = require('../middleware/auth');
const fs = require('fs');
const Item = require('../models/Item');

const useS3 = (process.env.USE_S3 === 'true');

if(!useS3){
  const uploadDir = path.resolve(process.env.LOCAL_UPLOAD_DIR || './uploads');
  fs.mkdirSync(uploadDir, { recursive: true });
  const storage = multer.diskStorage({
    destination: (req,file,cb) => cb(null, uploadDir),
    filename: (req,file,cb) => cb(null, uuidv4() + '-' + file.originalname.replace(/[^a-zA-Z0-9.\-_]/g,'_'))
  });
  const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });
  // upload multiple files, then create item
  router.post('/local', auth, upload.array('files', 10), async (req,res) => {
    const files = req.files.map(f => ({
      key: f.filename,
      url: `${req.protocol}://${req.get('host')}/uploads/${f.filename}`,
      filename: f.originalname,
      size: f.size,
      contentType: f.mimetype
    }));
    // optionally create item automatically if title provided
    const { title, description } = req.body;
    if(title){
      const item = new Item({ title, description, images: files, owner: req.user.id });
      await item.save();
      return res.json({ ok: true, item });
    }
    res.json({ ok: true, files });
  });
} else {
  // S3 presign flow
  const AWS = require('aws-sdk');
  const s3 = new AWS.S3({ region: process.env.S3_REGION || process.env.AWS_REGION });
  const BUCKET = process.env.S3_BUCKET;
  // presign endpoint expecting: files: [{ filename, contentType, size }]
  router.post('/presign', auth, async (req,res) => {
    try{
      const files = req.body.files;
      if(!Array.isArray(files) || files.length === 0) return res.status(400).json({ error: 'Files required' });
      const out = [];
      for(const f of files){
        if(f.size > 10*1024*1024) return res.status(400).json({ error: 'File too large' });
        if(!['image/jpeg','image/png','image/webp'].includes(f.contentType)) return res.status(400).json({ error: 'Bad type' });
        const key = `uploads/${uuidv4()}-${f.filename.replace(/[^a-zA-Z0-9.\-_]/g,'_')}`;
        const params = { Bucket: BUCKET, Key: key, Expires: 300, ContentType: f.contentType };
        const presignedUrl = await s3.getSignedUrlPromise('putObject', params);
        const publicUrl = `https://${BUCKET}.s3.${process.env.S3_REGION || process.env.AWS_REGION}.amazonaws.com/${key}`;
        out.push({ key, presignedUrl, url: publicUrl, filename: f.filename, contentType: f.contentType });
      }
      res.json(out);
    }catch(err){
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  });

  // after client uploads, create item record
  router.post('/create', auth, async (req,res) => {
    try{
      const { title, description, images } = req.body; // images: [{ key, url, filename, contentType }]
      if(!title || !Array.isArray(images)) return res.status(400).json({ error: 'Bad payload' });
      const item = new Item({ title, description, images, owner: req.user.id });
      await item.save();
      res.json(item);
    }catch(err){
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  });
}

module.exports = router;
