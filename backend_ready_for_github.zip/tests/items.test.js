const request = require('supertest');
const helper = require('./testHelper');
let app; let token;
beforeAll(async () => { app = await helper.start(); });
afterAll(async () => { await helper.stop(); });

test('create item and add feedback', async () => {
  const email = 'user2@example.com'; const password='password123';
  await request(app).post('/api/auth/register').send({ email, password });
  const login = await request(app).post('/api/auth/login').send({ email, password });
  token = login.body.token;
  // create item
  const create = await request(app).post('/api/items').set('Authorization', `Bearer ${token}`).send({ title: 'Test Item', description: 'desc', images: [] });
  expect(create.statusCode).toBe(200);
  const itemId = create.body._id;
  // add feedback
  const fb = await request(app).post(`/api/items/${itemId}/feedback`).send({ authorName: 'Anon', message: 'Nice' });
  expect(fb.statusCode).toBe(200);
  const get = await request(app).get(`/api/items/${itemId}`);
  expect(get.statusCode).toBe(200);
  expect(get.body.feedbacks.length).toBe(1);
  expect(get.body.feedbacks[0].message).toBe('Nice');
});
