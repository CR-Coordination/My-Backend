const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const app = require('../src/app');

let mongod;
module.exports = {
  start: async () => {
    mongod = await MongoMemoryServer.create();
    const uri = mongod.getUri();
    await mongoose.connect(uri);
    return app;
  },
  stop: async () => {
    await mongoose.disconnect();
    if(mongod) await mongod.stop();
  }
};
