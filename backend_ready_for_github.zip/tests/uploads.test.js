const request = require('supertest');
const helper = require('./testHelper');
let app;
beforeAll(async () => {
  process.env.USE_S3='true';
  process.env.S3_BUCKET='test-bucket';
  process.env.S3_REGION='us-east-1';
  app = await helper.start();
});
afterAll(async () => { await helper.stop(); });

test('presign requires files array', async () => {
  const res = await request(app).post('/api/uploads/presign').send({});
  expect(res.statusCode).toBe(400);
});
