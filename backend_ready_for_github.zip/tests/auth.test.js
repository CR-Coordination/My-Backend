const request = require('supertest');
const helper = require('./testHelper');
let app;
beforeAll(async () => { app = await helper.start(); });
afterAll(async () => { await helper.stop(); });

test('register and login flow', async () => {
  const email = 'testuser@example.com';
  const password = 'password123';
  const register = await request(app).post('/api/auth/register').send({ email, password });
  expect(register.statusCode).toBe(200);
  const login = await request(app).post('/api/auth/login').send({ email, password });
  expect(login.statusCode).toBe(200);
  expect(login.body).toHaveProperty('token');
  expect(login.body).toHaveProperty('user');
  expect(login.body.user.email).toBe(email);
});
